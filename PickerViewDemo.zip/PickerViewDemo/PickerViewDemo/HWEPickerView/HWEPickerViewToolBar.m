//
//  HWEPickerViewToolBar.m
//  PickerViewDemo
//
//  Created by Howie on 2019/1/11.
//  Copyright © 2019年 Howie. All rights reserved.
//  滚动选择器顶部的确认、取消工具条

#import "HWEPickerViewToolBar.h"

@interface HWEPickerViewToolBar ()

/// 标题
@property (strong, nonatomic) UILabel *titleLabel;
/// 确认按钮
@property (strong, nonatomic) UIButton *doneButton;
/// 取消按钮
@property (strong, nonatomic) UIButton *cancelButton;
/// 分割线
@property (strong, nonatomic) UIView *lineView;

/// 确认按钮的回调
@property (copy, nonatomic) ToolBarButtonAction doneAction;
/// 取消按钮的回调
@property (copy, nonatomic) ToolBarButtonAction cancelAction;

@end

@implementation HWEPickerViewToolBar

/**
 自定义初始化控件
 
 @param title 标题
 @param cancelAction 取消事件回调
 @param doneAction 确认事件回调
 @return 带标题和回调事件的工具条
 */
- (instancetype)initWithToolBarTitle:(NSString *)title cancelAction:(ToolBarButtonAction)cancelAction doneAction:(ToolBarButtonAction)doneAction
{
    if (self = [super init]) {
        
        self.titleLabel.text = (title.length == 0) ? @"选择器" : title;
        _doneAction = doneAction;
        _cancelAction = cancelAction;
        
        [self loadSubViews];
    }
    return self;
}

/// 加载子视图
- (void)loadSubViews
{
    [self addSubview:self.titleLabel];
    [self addSubview:self.doneButton];
    [self addSubview:self.cancelButton];
    [self addSubview:self.lineView];
}

/// 布局视图
- (void)layoutSubviews
{
    [super layoutSubviews];
    
    CGFloat padding = 10.0f;
    CGFloat btnWidth = 44.0f;
    CGFloat lineViewHeight = 1.0f;
    
    CGFloat btnOrLabelHeight = self.bounds.size.height - lineViewHeight;
    CGFloat selfWidth = self.bounds.size.width;
    
    {
        CGRect cancelBtnRect = CGRectZero;
        cancelBtnRect.origin.x = padding;
        cancelBtnRect.size.width = btnWidth;
        cancelBtnRect.size.height = btnOrLabelHeight;
        self.cancelButton.frame = cancelBtnRect;
    }
    
    {
        CGRect doneBtnRect = CGRectZero;
        doneBtnRect.size.width = btnWidth;
        doneBtnRect.origin.x = selfWidth - padding - doneBtnRect.size.width;
        doneBtnRect.size.height = btnOrLabelHeight;
        self.doneButton.frame = doneBtnRect;
    }
    
    {
        CGRect labelRect = CGRectZero;
        labelRect.origin.x = CGRectGetMaxX(self.cancelButton.frame) + padding;
        labelRect.size.width = selfWidth - labelRect.origin.x - 2*padding - btnWidth;
        labelRect.size.height = btnOrLabelHeight;
        self.titleLabel.frame = labelRect;
    }
    
    {
        self.lineView.frame = CGRectMake(0.0, btnOrLabelHeight, selfWidth, lineViewHeight);
    }
}

- (void)dealloc {
    NSLog(@"HWEPickerViewToolBar --- dealloc");
}

#pragma mark - button Action
/// 确认按钮响应事件
- (void)doneBtnOnClick:(UIButton *)sender
{
    if (self.doneAction) {
        self.doneAction(sender);
    }
}

/// 取消按钮响应事件
- (void)cancelBtnOnClick:(UIButton *)sender
{
    if (self.cancelAction) {
        self.cancelAction(sender);
    }
}

#pragma mark - getter
- (UIButton *)doneButton
{
    if (!_doneButton) {
        UIButton *btn = [[UIButton alloc] init];
        [btn addTarget:self action:@selector(doneBtnOnClick:) forControlEvents:UIControlEventTouchUpInside];
        [btn setTitle:@"完成" forState:UIControlStateNormal];
        btn.titleLabel.font = [UIFont boldSystemFontOfSize:18.0f];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _doneButton = btn;
    }
    
    return _doneButton;
}

- (UIButton *)cancelButton
{
    if (!_cancelButton) {
        UIButton *btn = [[UIButton alloc] init];
        [btn addTarget:self action:@selector(cancelBtnOnClick:) forControlEvents:UIControlEventTouchUpInside];
        [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        btn.titleLabel.font = [UIFont boldSystemFontOfSize:18.0f];
        [btn setTitle:@"取消" forState:UIControlStateNormal];
        _cancelButton = btn;
    }
    
    return _cancelButton;
}

- (UILabel *)titleLabel
{
    if (!_titleLabel) {
        UILabel *label = [UILabel new];
        label.textColor = [UIColor blackColor];
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont boldSystemFontOfSize:16.0f];
        _titleLabel = label;
    }
    
    return _titleLabel;
}

- (UIView *)lineView
{
    if (!_lineView) {
        _lineView = [UIView new];
        _lineView.backgroundColor = [UIColor lightGrayColor];
    }
    return _lineView;
}

@end
