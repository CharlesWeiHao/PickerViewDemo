//
//  HWEPickerView.m
//  PickerViewDemo
//
//  Created by Howie on 2019/1/11.
//  Copyright © 2019年 Howie. All rights reserved.
//  滚动选择器

#import "HWEPickerView.h"
#import "HWEPickerViewToolBar.h"
#import "HWERelatedPickerView.h"
#import "HWDUnrelatedPickerView.h"

/// 默认pickerview的高度
static const CGFloat kPickerViewHeight = 260.0f;

@interface HWEPickerView ()
/// 自定义view，可替代不同类型的pickerview
@property (strong, nonatomic) UIView *pickerView;

@end

@implementation HWEPickerView

#pragma mark - life cycle
- (instancetype)init {
    if (self = [super init]) {
        UITapGestureRecognizer *tapGes = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapedSelf:)];
        tapGes.numberOfTapsRequired = 1;
        [self addGestureRecognizer:tapGes];
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

- (void)dealloc {
    NSLog(@"HWEPickerView --- dealloc");
}

- (void)tapedSelf:(UITapGestureRecognizer *)tap {
    CGPoint location = [tap locationInView:self];
    
    // 点击空白背景移除self
    if (location.y <= [UIScreen mainScreen].bounds.size.height - kPickerViewHeight) {
        [self hidePickerView];
    }
}

#pragma mark - public methods
/**
 展示关联的数据
 
 @param title 滚动视图的标题
 @param defaultIndexs 默认选中数据的下标
 @param data 展示的数据， 格式查看 ‘text.json’ 文件数据
 @param cancelHandler 取消回调
 @param doneHandler 确认回调
 @return 关联滚动视图
 */
+ (instancetype)showRelatedPickerViewWithToolBarTitle:(nullable NSString *)title defaultIndexs:(nullable NSArray *)defaultIndexs data:(NSArray<NSArray *> *)data cancelHandler:(CancelHandler)cancelHandler doneHandler:(DoneHandler)doneHandler
{
    HWEPickerView *pickerView = [HWEPickerView new];
    __weak HWEPickerView *weakPickerView = pickerView;
    
    HWERelatedPickerView *relatedPickerView = [[HWERelatedPickerView alloc] initWithToolBarTitle:title defauletIndexs:defaultIndexs data:data selectedHandler:nil cancelHandler:^{
        if (cancelHandler) {
            cancelHandler();
        }
        
        __strong HWEPickerView * strongPickerView = weakPickerView;
        if (strongPickerView) {
            [strongPickerView hidePickerView];
        }
    } doneHandler:^(NSArray * _Nonnull selectedValues, NSArray * _Nonnull selectedIndexs) {
        if (doneHandler) {
            doneHandler(selectedIndexs, selectedValues);
        }
        
        __strong HWEPickerView * strongPickerView = weakPickerView;
        if (strongPickerView) {
            [strongPickerView hidePickerView];
        }
    }];
    
    pickerView.pickerView = relatedPickerView;
    [pickerView showPickerView];
    
    return pickerView;
}


/**
 展示非关联的数据
 
 @param title 滚动视图的标题
 @param defaultIndexs 默认选中数据的下标
 @param data 展示的数据， 格式 数组嵌套数组 @[@[...],@[...],@[...]]
 @param cancelHandler 取消回调
 @param doneHandler 确认回调
 @return 非关联滚动视图
 */
+ (instancetype)showUnRelatedPickerViewWithToolBarTitle:(nullable NSString *)title defaultIndexs:(nullable NSArray *)defaultIndexs data:(NSArray<NSArray *> *)data cancelHandler:(CancelHandler)cancelHandler doneHandler:(DoneHandler)doneHandler
{
    HWEPickerView *pickerView = [HWEPickerView new];
    
    __weak HWEPickerView *weakPickerView = pickerView;
    
    
    
    HWDUnrelatedPickerView *unrelatedPickerView = [[HWDUnrelatedPickerView alloc] initWithToolBarTitle:title defauletIndexs:defaultIndexs data:data selectedHandler:nil cancelHandler:^{
        if (cancelHandler) {
            cancelHandler();
        }
        
        __strong HWEPickerView * strongPickerView = weakPickerView;
        if (strongPickerView) {
            [strongPickerView hidePickerView];
        }
    } doneHandler:^(NSArray * _Nonnull selectedValues, NSArray * _Nonnull selectedIndexs) {
        if (doneHandler) {
            doneHandler(selectedIndexs, selectedValues);
        }
        
        __strong HWEPickerView * strongPickerView = weakPickerView;
        if (strongPickerView) {
            [strongPickerView hidePickerView];
        }
    }];
    
    pickerView.pickerView = unrelatedPickerView;
    [pickerView showPickerView];
    
    return pickerView;
}

#pragma mark - helper
- (void)showPickerView {
    UIWindow *window = [[UIApplication sharedApplication] keyWindow];
    if (window) {
        /// 移除键盘第一响应者, 否则键盘始终会在界面的最上层
        [window endEditing:YES];
        /// 添加view
        [window addSubview:self];
        /// 设置pickerView的frame为屏幕底部外面 --- 动画初始位置
        self.pickerView.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height, [UIScreen mainScreen].bounds.size.width, kPickerViewHeight);
        
        [UIView animateWithDuration:0.25f animations:^{
            self.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.1];
            /// 设置pickerView的动画结束位置, 显示在屏幕底部
            self.pickerView.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height - kPickerViewHeight, [UIScreen mainScreen].bounds.size.width, kPickerViewHeight);;
        } completion:nil];
    }
}

- (void)hidePickerView {
    [UIView animateWithDuration:0.25f animations:^{
        self.backgroundColor = [UIColor clearColor];
        self.pickerView.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height, [UIScreen mainScreen].bounds.size.width, kPickerViewHeight);
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
        
    }];
    
}

- (void)layoutSubviews {
    [super layoutSubviews];
    if (self.superview) {
        self.frame = self.superview.bounds;
        self.pickerView.frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height - kPickerViewHeight, [UIScreen mainScreen].bounds.size.width, kPickerViewHeight);
    }
}

#pragma mark - setter getter
- (void)setPickerView:(UIView *)pickerView {
    _pickerView = pickerView;
    [self addSubview:_pickerView];
}

- (HWEPickerViewToolBar *)toolBar {
    if ([self.pickerView isKindOfClass:[HWERelatedPickerView class]]) {
        return ((HWERelatedPickerView *)self.pickerView).toolBar;
    }
    else if ([self.pickerView isKindOfClass:[HWDUnrelatedPickerView class]]) {
        return ((HWDUnrelatedPickerView *)self.pickerView).toolBar;
    }
    else {
        return [HWEPickerViewToolBar new];
    }
}

@end
