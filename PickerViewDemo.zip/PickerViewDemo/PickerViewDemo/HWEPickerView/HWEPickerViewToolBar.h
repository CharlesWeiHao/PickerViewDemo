//
//  HWEPickerViewToolBar.h
//  PickerViewDemo
//
//  Created by Howie on 2019/1/11.
//  Copyright © 2019年 Howie. All rights reserved.
//  滚动选择器顶部的确认、取消工具条

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWEPickerViewToolBar : UIView

/// 确认和取消按钮的事件回调
typedef void(^ToolBarButtonAction)();

/**
 自定义初始化控件

 @param title 标题
 @param cancelAction 取消事件回调
 @param doneAction 确认事件回调
 @return 带标题和回调事件的工具条
 */
- (instancetype)initWithToolBarTitle:(nullable NSString *)title cancelAction:(ToolBarButtonAction)cancelAction doneAction:(ToolBarButtonAction)doneAction;

@end

NS_ASSUME_NONNULL_END
