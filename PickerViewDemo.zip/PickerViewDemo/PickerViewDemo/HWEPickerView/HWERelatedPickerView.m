//
//  HWERelatedPickerView.m
//  PickerViewDemo
//
//  Created by Howie on 2019/1/11.
//  Copyright © 2019年 Howie. All rights reserved.
//  数据关联的滚动选择器

#import "HWERelatedPickerView.h"
#import <MJExtension.h>
@interface HWERelatedPickerView()<UIPickerViewDelegate, UIPickerViewDataSource>

/// 选择器
@property (strong, nonatomic) UIPickerView *pickerView;
/// 第一行数据
@property(nonatomic , strong) NSMutableArray *firstRowData;
/// 第二行数据
@property(nonatomic , strong) NSMutableArray *secondRowData;
/// 第三行数据
@property(nonatomic , strong) NSMutableArray *thirdRowData;
/// 选中的对象
@property(nonatomic , strong) NSMutableDictionary *selectedDic;
/// 选中数据的下标值
@property (strong, nonatomic) NSMutableArray *selectedIndexs;
/// 选中的数据
@property (strong, nonatomic) NSMutableArray *selectedValues;
/// 选中数据回调
@property (copy,   nonatomic) SelectedHandler selectedHandler;
@end

@implementation HWERelatedPickerView

/**
 数据有关联的选择器
 
 @param title 标题
 @param defaultIndexs 默认选中数据的下标值
 @param data 展示数据
 @param selectedHandler 选中的数据
 @param cancelHandler 取消回调
 @param doneHandler 确认回调
 @return 关联数据的选择器
 */
- (instancetype)initWithToolBarTitle:(nullable NSString *)title defauletIndexs:(nullable NSArray *)defaultIndexs data:(NSArray *)data selectedHandler:(SelectedHandler)selectedHandler cancelHandler:(ToolBarButtonAction)cancelHandler doneHandler:(DoneHandler)doneHandler
{
    if (self = [super init]) {
        
        /// 检查数据格式
        if ([self checkData:data] == NO) {
            NSLog(@"数据格式错误，初始化失败！");
            return nil;
        }
        
        // 默认选中的下标值
        self.selectedIndexs = [defaultIndexs mutableCopy];
        if (self.selectedIndexs == nil || self.selectedIndexs.count == 0) {
            // 如果没有指定默认值，就全部设定为0
            for (int i = 0; i< data.count; i++) {
                [self.selectedIndexs addObject:@0];
            }
        }
        
        // 设置数据
        [self setRowData:data];
        _selectedHandler = selectedHandler;
        
        /// 添加工具条
        __weak typeof(self) weakSelf = self;
        _toolBar = [[HWEPickerViewToolBar alloc] initWithToolBarTitle:title cancelAction:cancelHandler doneAction:^(UIButton * _Nonnull sender) {
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (strongSelf) {
                if (doneHandler) {
                    doneHandler(strongSelf.selectedIndexs, strongSelf.selectedValues);
                }
            }
        }];

        /// 添加view
        self.backgroundColor = [UIColor whiteColor];
        [self addSubview:self.pickerView];
        [self addSubview:self.toolBar];
        
        // 设置选中的值
        [self setupSelectedValueDidChanged];
        /// 滚动到指定位置
        [self selectTheDefaultValues];
        
    }
    return self;
}

/// 检查数据格式
- (BOOL)checkData:(NSArray *)data {
    BOOL isRight = NO;
    if (data && [data isKindOfClass:[NSArray class]]) {
        for (id object in data) {
            if ([object isKindOfClass:[NSDictionary class]]) {
                isRight = YES;
            }
        }
    }
    return isRight;
}

/// 把数据做转换
- (void)setRowData:(NSArray *)data {
    // 数据为空，放回数据
    if (data.count == 0) {
        return;
    }
    
    // 第一行
    self.firstRowData = [NSDictionary mj_objectArrayWithKeyValuesArray:data];
    
    // 第一个数据
    NSInteger index1 = [self.selectedIndexs[0] integerValue];
    NSDictionary *firstModel = self.firstRowData[index1];
    self.secondRowData = [NSDictionary mj_objectArrayWithKeyValuesArray:firstModel[@"next"]];
    
    // 第二个数据
    NSInteger index2 = [self.selectedIndexs[1] integerValue];
    NSDictionary *secondModel = self.secondRowData[index2];
    self.thirdRowData = [NSDictionary mj_objectArrayWithKeyValuesArray:secondModel[@"next"]];
    
    // 第三行数据
    NSInteger index3 = [self.selectedIndexs[2] integerValue];
    NSDictionary *thridModel = self.thirdRowData[index3];
    
    // 选中对象的值
    [self.selectedDic setValue:firstModel[@"text"] forKey:@"firstRow"];
    [self.selectedDic setValue:[NSNumber numberWithInteger:index1] forKey:@"firstIndex"];
    
    [self.selectedDic setValue:secondModel[@"text"] forKey:@"secondRow"];
    [self.selectedDic setValue:[NSNumber numberWithInteger:index2] forKey:@"secondIndex"];
    
    [self.selectedDic setValue:thridModel[@"text"] forKey:@"thridRow"];
    [self.selectedDic setValue:[NSNumber numberWithInteger:index3] forKey:@"thridIndex"];
}

/// 滚动到指定位置
- (void)selectTheDefaultValues {
    /// 遍历滚动到选中的下标值
    [self.selectedIndexs enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger component, BOOL * _Nonnull stop) {
        // 默认下标值
        NSInteger defaultIndex = [obj integerValue];
        [self.pickerView selectRow:defaultIndex inComponent:component animated:NO];
    }];
}

/// 验证完毕，默认选中值改变
- (void)setupSelectedValueDidChanged {
    
    if (self.selectedIndexs.count > 0) {
        [self.selectedIndexs removeAllObjects];
    }
    
    // 下标值
    [self.selectedIndexs addObject:self.selectedDic[@"firstIndex"]];
    [self.selectedIndexs addObject:self.selectedDic[@"secondIndex"]];
    [self.selectedIndexs addObject:self.selectedDic[@"thridIndex"]];
    
    
    if (self.selectedValues.count > 0) {
        [self.selectedValues removeAllObjects];
    }
    // 选中的值
    [self.selectedValues addObject:self.selectedDic[@"firstRow"]];
    [self.selectedValues addObject:self.selectedDic[@"secondRow"]];
    [self.selectedValues addObject:self.selectedDic[@"thridRow"]];
    
    // 返回的数据
    if (_selectedHandler) {
        _selectedHandler(self.selectedValues);
    }
}

#pragma Mark -- UIPickerViewDataSource
// pickerView 列数
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return _selectedIndexs.count;
}

// pickerView 每列个数
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    
    switch (component) {
        case 0:
            return self.firstRowData.count;
            break;
        case 1:
            return self.secondRowData.count;
            break;
        case 2:
            return self.thirdRowData.count;
            break;
            
        default:
            return 0;
            break;
    }
}
// 返回选中的行
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    NSLog(@"选中%ld列---%ld行",(long)component,(long)row);
    
    if (component==0) {
        // 第一行
        NSDictionary *firstModel = self.firstRowData[row];
        self.secondRowData = [NSDictionary mj_objectArrayWithKeyValuesArray:firstModel[@"next"]];
        [pickerView reloadComponent:1];
        [pickerView selectRow:0 inComponent:1 animated:NO];
        
        // 第二行 默认选择第一个数据
        NSDictionary *secondModel = self.secondRowData[0];
        self.thirdRowData = [NSDictionary mj_objectArrayWithKeyValuesArray:secondModel[@"next"]];
        [pickerView reloadComponent:2];
        [pickerView selectRow:0 inComponent:2 animated:NO];
        
        // 第三行
        NSDictionary *thridModel = self.thirdRowData[0];
        
        // 把选中的对象放到数组中
        [self.selectedDic setValue:firstModel[@"text"] forKey:@"firstRow"];
        [self.selectedDic setValue:[NSNumber numberWithInteger:row] forKey:@"firstIndex"];
        
        [self.selectedDic setValue:secondModel[@"text"] forKey:@"secondRow"];
        [self.selectedDic setValue:@0 forKey:@"secondIndex"];
        
        [self.selectedDic setValue:thridModel[@"text"] forKey:@"thridRow"];
        [self.selectedDic setValue:@0 forKey:@"thridIndex"];
        
    }
    else if (component==1) {
        NSDictionary *secondModel = self.secondRowData[row];
        self.thirdRowData = [NSDictionary mj_objectArrayWithKeyValuesArray:secondModel[@"next"]];
        
        [pickerView reloadComponent:2];
        [pickerView selectRow:0 inComponent:2 animated:NO];
        
        NSDictionary *thridModel = self.thirdRowData[0];
        
        // 替换数据
        [self.selectedDic setValue:secondModel[@"text"] forKey:@"secondRow"];
        [self.selectedDic setValue:[NSNumber numberWithInteger:row] forKey:@"secondIndex"];
        
        [self.selectedDic setValue:thridModel[@"text"] forKey:@"thridRow"];
        [self.selectedDic setValue:@0 forKey:@"thridIndex"];
        
    }
    else if (component==2) {
        NSDictionary *thridModel = self.thirdRowData[row];
        [self.selectedDic setValue:thridModel[@"text"] forKey:@"thridRow"];
        [self.selectedDic setValue:[NSNumber numberWithInteger:row] forKey:@"thridIndex"];
    }
    
    // 设置选中的值
    [self setupSelectedValueDidChanged];
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
    UILabel *label = [UILabel new];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor blackColor];
    label.font = [UIFont systemFontOfSize:18.0f];
    label.backgroundColor = [UIColor clearColor];
    label.adjustsFontSizeToFitWidth = YES;
    
    NSString *rowTitle = @"";
    switch (component) {
        case 0: // 第0行
            rowTitle = self.firstRowData[row][@"text"];
            break;
        case 1: // 第1行
            rowTitle = self.secondRowData[row][@"text"];
            break;
        case 2: // 第2行
            rowTitle = self.thirdRowData[row][@"text"];
            break;
        default:
            break;
    }
    label.text = rowTitle;
    return label;
}

#pragma mark - layoutSubviews
/// 自动布局
- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGFloat kToolBarHeight = 44.0f;
    
    NSLayoutConstraint *toolBarLeft = [NSLayoutConstraint constraintWithItem:self.toolBar attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeading multiplier:1.0 constant:0.0f];
    NSLayoutConstraint *toolBarRight = [NSLayoutConstraint constraintWithItem:self.toolBar attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTrailing multiplier:1.0 constant:0.0f];
    
    NSLayoutConstraint *toolBarHeight = [NSLayoutConstraint constraintWithItem:self.toolBar attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:kToolBarHeight];
    NSLayoutConstraint *toolBarTop = [NSLayoutConstraint constraintWithItem:self.toolBar attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTop multiplier:1.0 constant:0.0f];
    self.toolBar.translatesAutoresizingMaskIntoConstraints = NO;
    [self addConstraints:@[toolBarLeft, toolBarRight, toolBarHeight, toolBarTop]];
    
    NSLayoutConstraint *pickerViewLeft = [NSLayoutConstraint constraintWithItem:self.pickerView attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeading multiplier:1.0 constant:0.0f];
    NSLayoutConstraint *pickerViewRight = [NSLayoutConstraint constraintWithItem:self.pickerView attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTrailing multiplier:1.0 constant:0.0f];
    
    NSLayoutConstraint *pickerViewHeight = [NSLayoutConstraint constraintWithItem:self.pickerView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:self.bounds.size.height - kToolBarHeight];
    NSLayoutConstraint *pickerViewBottom = [NSLayoutConstraint constraintWithItem:self.pickerView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeBottom multiplier:1.0 constant:0.0f];
    self.pickerView.translatesAutoresizingMaskIntoConstraints = NO;
    [self addConstraints:@[pickerViewLeft, pickerViewRight, pickerViewHeight, pickerViewBottom]];
}

- (void)dealloc {
    NSLog(@"HWERelatedPickerView --- dealloc");
}

#pragma mark - getter
- (NSMutableArray *)firstRowData {
    if (_firstRowData == nil) {
        _firstRowData = [NSMutableArray array];
    }
    return _firstRowData;
}

- (NSMutableArray *)secondRowData {
    if (_secondRowData == nil) {
        _secondRowData = [NSMutableArray array];
    }
    return _secondRowData;
}

- (NSMutableArray *)thirdRowData {
    if (_thirdRowData == nil) {
        _thirdRowData = [NSMutableArray array];
    }
    return _thirdRowData;
}

- (NSMutableDictionary *)selectedDic {
    if (_selectedDic == nil) {
        _selectedDic = [NSMutableDictionary dictionary];
    }
    return _selectedDic;
}

- (NSMutableArray *)selectedIndexs {
    if (_selectedIndexs == nil) {
        _selectedIndexs = [NSMutableArray array];
    }
    return _selectedIndexs;
}

- (NSMutableArray *)selectedValues {
    if (_selectedValues == nil) {
        _selectedValues = [NSMutableArray array];
    }
    return _selectedValues;
}

- (UIPickerView *)pickerView {
    if (!_pickerView) {
        _pickerView = [[UIPickerView alloc] init];
        _pickerView.delegate = self;
        _pickerView.dataSource = self;
    }
    return _pickerView;
}

@end
