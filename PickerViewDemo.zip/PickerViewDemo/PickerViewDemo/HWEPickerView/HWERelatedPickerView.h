//
//  HWERelatedPickerView.h
//  PickerViewDemo
//
//  Created by Howie on 2019/1/11.
//  Copyright © 2019年 Howie. All rights reserved.
//  数据关联的滚动选择器

#import <UIKit/UIKit.h>
#import "HWEPickerViewToolBar.h"

NS_ASSUME_NONNULL_BEGIN

@interface HWERelatedPickerView : UIView

/// 确认按钮的回调事件
typedef void(^DoneHandler) (NSArray *selectedValues, NSArray *selectedIndexs);
/// 选中的数据
typedef void(^SelectedHandler)(NSArray *selectedValues);

/// 确认和取消的工具条
@property (strong, nonatomic) HWEPickerViewToolBar *toolBar;

/**
 数据有关联的选择器

 @param title 标题
 @param defaultIndexs 默认选中数据的下标值
 @param data 展示数据
 @param selectedHandler 选中的数据
 @param cancelHandler 取消回调
 @param doneHandler 确认回调
 @return 关联数据的选择器
 */
- (instancetype)initWithToolBarTitle:(nullable NSString *)title defauletIndexs:(nullable NSArray *)defaultIndexs data:(NSArray *)data selectedHandler:(SelectedHandler)selectedHandler cancelHandler:(ToolBarButtonAction)cancelHandler doneHandler:(DoneHandler)doneHandler;

@end

NS_ASSUME_NONNULL_END
