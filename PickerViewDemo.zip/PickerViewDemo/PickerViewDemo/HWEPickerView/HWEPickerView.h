//
//  HWEPickerView.h
//  PickerViewDemo
//
//  Created by Howie on 2019/1/11.
//  Copyright © 2019年 Howie. All rights reserved.
//  滚动选择器

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HWEPickerView : UIView

/// 取消按钮的回调事件
typedef void(^CancelHandler) ();
/// 确认按钮的回调事件
typedef void(^DoneHandler) (NSArray *selectedValues, NSArray *selectedIndexs);

/**
 展示关联的数据

 @param title 滚动视图的标题
 @param defaultIndexs 默认选中数据的下标
 @param data 展示的数据， 格式查看 ‘text.json’ 文件数据
 @param cancelHandler 取消回调
 @param doneHandler 确认回调
 @return 关联滚动视图
 */
+ (instancetype)showRelatedPickerViewWithToolBarTitle:(nullable NSString *)title defaultIndexs:(nullable NSArray *)defaultIndexs data:(NSArray *)data cancelHandler:(CancelHandler)cancelHandler doneHandler:(DoneHandler)doneHandler;


/**
 展示非关联的数据
 
 @param title 滚动视图的标题
 @param defaultIndexs 默认选中数据的下标
 @param data 展示的数据， 格式 数组嵌套数组 @[@[...],@[...],@[...]]
 @param cancelHandler 取消回调
 @param doneHandler 确认回调
 @return 非关联滚动视图
 */
+ (instancetype)showUnRelatedPickerViewWithToolBarTitle:(nullable NSString *)title defaultIndexs:(nullable NSArray *)defaultIndexs data:(NSArray<NSArray *> *)data cancelHandler:(CancelHandler)cancelHandler doneHandler:(DoneHandler)doneHandler;


@end

NS_ASSUME_NONNULL_END
