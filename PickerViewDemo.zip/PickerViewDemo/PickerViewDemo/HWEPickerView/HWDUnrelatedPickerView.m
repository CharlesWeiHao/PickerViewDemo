//
//  HWDUnrelatedPickerView.m
//  PickerViewDemo
//
//  Created by Howie on 2019/1/11.
//  Copyright © 2019年 Howie. All rights reserved.
//  数据非关联的滚动选择器


#import "HWDUnrelatedPickerView.h"
#import "HWEPickerViewToolBar.h"

@interface HWDUnrelatedPickerView ()<UIPickerViewDelegate, UIPickerViewDataSource>

@property (strong, nonatomic) UIPickerView *pickerView;
@property (strong, nonatomic) NSArray<NSArray *> *data;
@property (strong, nonatomic) NSMutableArray *selectedIndexs;
@property (strong, nonatomic) NSArray *selectedValues;
@property (copy,   nonatomic) SelectedHandler selectedHandler;

@end


@implementation HWDUnrelatedPickerView

/**
 数据非关联的选择器
 
 @param title 标题
 @param defaultIndexs 默认选中数据的下标值
 @param data 展示数据
 @param selectedHandler 选中数据
 @param cancelHandler 取消回调
 @param doneHandler 确认回调
 @return 非关联数据的选择器
 */
- (instancetype)initWithToolBarTitle:(nullable NSString *)title defauletIndexs:(nullable NSArray *)defaultIndexs data:(NSArray<NSArray *> *)data selectedHandler:(SelectedHandler)selectedHandler cancelHandler:(ToolBarButtonAction)cancelHandler doneHandler:(DoneHandler)doneHandler;

{
    if (self = [super init]) {
        /// 验证给定的数据格式是否正确
        if ([self checkData:data] == NO) {
            NSLog(@"数据格式错误，初始化失败！");
            return nil;
        }
        
        _data = data;
        _selectedHandler = selectedHandler;
        
        /// 添加工具条
        __weak typeof(self) weakSelf = self;
        _toolBar = [[HWEPickerViewToolBar alloc] initWithToolBarTitle:title cancelAction:cancelHandler doneAction:^(UIButton * _Nonnull sender) {
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (strongSelf) {
                if (doneHandler) {
                    doneHandler(strongSelf.selectedIndexs, strongSelf.selectedValues);
                }
            }
        }];
        self.backgroundColor = [UIColor whiteColor];
        [self addSubview:self.pickerView];
        [self addSubview:self.toolBar];
        
        _selectedIndexs = [defaultIndexs mutableCopy];
        if (_selectedIndexs == nil || _selectedIndexs.count == 0) {
            // 如果没有指定默认值，就全部设定为0
            _selectedIndexs = [NSMutableArray array];
            for (int i = 0; i< data.count; i++) {
                [_selectedIndexs addObject:@0];
            }
        }
        
        /// 设置默认值
        [self congifTheDefaultValues];
        
        /// 验证完毕，默认选中值改变
        [self setupSelectedValueDidChanged];
        
        /// 滚到指定位置
        [self selectTheDefaultValues];
        
    }
    
    return self;
}

/// 验证给定的数据格式是否正确
- (BOOL)checkData:(NSArray *)data {
    BOOL isRight = NO;
    if (data && [data isKindOfClass:[NSArray class]]) {
        for (id object in data) {
            if ([object isKindOfClass:[NSArray class]]) {
                isRight = YES;
            }
        }
    }
    return isRight;
}

/// 设置默认值
- (void)congifTheDefaultValues
{
    if (_selectedIndexs.count < _data.count) { // 默认值的个数<列的个数时
        while (_selectedIndexs.count < _data.count) {// 补全默认值得个数
            [_selectedIndexs addObject:@0];
        }
    }
    else if (_selectedIndexs.count > _data.count) {// 移除多余的
        NSInteger index = _data.count;
        while (_data.count < _selectedIndexs.count) {
            [_selectedIndexs removeObjectAtIndex:index];
        }
    }

    NSArray *tempDefaultIndexs = [_selectedIndexs copy];
    // 现在个数已经相同, 判断每一个下标是否合法
    [tempDefaultIndexs enumerateObjectsUsingBlock:^(NSNumber   * _Nonnull obj, NSUInteger index, BOOL * _Nonnull stop) {

        NSInteger defaultIndex = [obj integerValue];

        NSArray *values = self.data[index];

        if (defaultIndex < 0 || defaultIndex >= values.count) {
            // 重置为0
            [self.selectedIndexs replaceObjectAtIndex:index withObject:@0];

        }

    }];
}

/// 验证完毕，默认选中值改变
- (void)setupSelectedValueDidChanged {
    if (_selectedHandler) {
        _selectedHandler(self.selectedValues);
    }
}


/// 滚动到指定位置
- (void)selectTheDefaultValues {
    [_selectedIndexs enumerateObjectsUsingBlock:^(NSNumber   * _Nonnull obj, NSUInteger component, BOOL * _Nonnull stop) {
        NSInteger row = [obj integerValue];
        [self.pickerView selectRow:row inComponent:component animated:NO];
    }];
}

/// 自动布局
- (void)layoutSubviews {
    [super layoutSubviews];
    
    CGFloat kToolBarHeight = 44.0f;
    
    NSLayoutConstraint *toolBarLeft = [NSLayoutConstraint constraintWithItem:self.toolBar attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeading multiplier:1.0 constant:0.0f];
    NSLayoutConstraint *toolBarRight = [NSLayoutConstraint constraintWithItem:self.toolBar attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTrailing multiplier:1.0 constant:0.0f];
    
    NSLayoutConstraint *toolBarHeight = [NSLayoutConstraint constraintWithItem:self.toolBar attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:kToolBarHeight];
    NSLayoutConstraint *toolBarTop = [NSLayoutConstraint constraintWithItem:self.toolBar attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTop multiplier:1.0 constant:0.0f];
    self.toolBar.translatesAutoresizingMaskIntoConstraints = NO;
    [self addConstraints:@[toolBarLeft, toolBarRight, toolBarHeight, toolBarTop]];
    
    NSLayoutConstraint *pickerViewLeft = [NSLayoutConstraint constraintWithItem:self.pickerView attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeLeading multiplier:1.0 constant:0.0f];
    NSLayoutConstraint *pickerViewRight = [NSLayoutConstraint constraintWithItem:self.pickerView attribute:NSLayoutAttributeTrailing relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTrailing multiplier:1.0 constant:0.0f];
    
    NSLayoutConstraint *pickerViewHeight = [NSLayoutConstraint constraintWithItem:self.pickerView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.0 constant:self.bounds.size.height - kToolBarHeight];
    NSLayoutConstraint *pickerViewBottom = [NSLayoutConstraint constraintWithItem:self.pickerView attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeBottom multiplier:1.0 constant:0.0f];
    self.pickerView.translatesAutoresizingMaskIntoConstraints = NO;
    [self addConstraints:@[pickerViewLeft, pickerViewRight, pickerViewHeight, pickerViewBottom]];
}

- (void)dealloc {
    NSLog(@"HWDUnrelatedPickerView --- dealloc");
}

#pragma mark - UIPickerViewDelegate, UIPickerViewDataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return _data.count;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return _data[component].count;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    // 设置选中下标
    [_selectedIndexs replaceObjectAtIndex:component withObject:[NSNumber numberWithInteger:row]];
    [self setupSelectedValueDidChanged];
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
    UILabel *label = [UILabel new];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor blackColor];
    label.font = [UIFont systemFontOfSize:18.0f];
    label.backgroundColor = [UIColor clearColor];
    label.adjustsFontSizeToFitWidth = YES;
    label.text = _data[component][row][@"text"];
    return label;
}


#pragma mark - getter
/// 选中的数据值
- (NSArray *)selectedValues {
    NSMutableArray *array = [NSMutableArray array];
    [_selectedIndexs enumerateObjectsUsingBlock:^(NSNumber   * _Nonnull obj, NSUInteger index, BOOL * _Nonnull stop) {

        NSInteger defaultIndex = [obj integerValue];
        NSArray *values = self.data[index];
        [array addObject:values[defaultIndex]];
        
    }];
    return array;
}

- (UIPickerView *)pickerView {
    if (!_pickerView) {
        _pickerView = [[UIPickerView alloc] init];
        _pickerView.delegate = self;
        _pickerView.dataSource = self;
        
    }
    return _pickerView;
}


@end
