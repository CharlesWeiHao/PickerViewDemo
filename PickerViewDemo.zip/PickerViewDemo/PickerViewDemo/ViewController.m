//
//  ViewController.m
//  PickerViewDemo
//
//  Created by Howie on 2019/1/11.
//  Copyright © 2019年 Howie. All rights reserved.
//

#import "ViewController.h"
#import "HWEPickerView/HWEPickerView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}
- (IBAction)unrelated:(id)sender {
    
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"unRelated" ofType:@"json"];
    NSData *jsonData = [NSData dataWithContentsOfFile:filePath];
    NSArray *data = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:nil];
    
    [HWEPickerView showUnRelatedPickerViewWithToolBarTitle:@"非关联数据" defaultIndexs:@[@1,@1,@1] data:data cancelHandler:^{
        NSLog(@"---点击了取消按钮---");
    } doneHandler:^(NSArray * _Nonnull selectedValues, NSArray * _Nonnull selectedIndexs) {
        NSLog(@"selectedValues - > %@\nselectedIndexs- > %@",selectedValues,selectedIndexs );
    }];
}

- (IBAction)related:(id)sender {
    
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"related" ofType:@"json"];
    NSData *jsonData = [NSData dataWithContentsOfFile:filePath];
    NSArray *data = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingAllowFragments error:nil];
    
    [HWEPickerView showRelatedPickerViewWithToolBarTitle:@"关联数据" defaultIndexs:@[@1,@1,@1] data:data cancelHandler:^{
        NSLog(@"---点击了取消按钮---");

    } doneHandler:^(NSArray * _Nonnull selectedValues, NSArray * _Nonnull selectedIndexs) {
        NSLog(@"selectedValues - > %@\nselectedIndexs- > %@",selectedValues,selectedIndexs );
    }];
}

@end
